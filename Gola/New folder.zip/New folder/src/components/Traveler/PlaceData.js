
const placeList = [
 
  {
    id: 2,
    name: "Mount Lavinia Beach",
    description: "Southern Hotel of our island",
    img: "https://www.frommilesaway.com.au/wp-content/uploads/2018/07/Sri-Lanka-Mount-Lavinia-Beach-Colombo-2.jpg",
  },
  {
    id: 3,
    name: "Unavatuna Beach Hotel",
    description: "Southern Hotel of our island",
    img: "https://do6raq9h04ex.cloudfront.net/sites/2/2021/03/146439688_1075312069646476_6626974179216859201_o.jpg",
  },
  {
    id: 4,
    name: "Unavatuna Beach Hotel",
    description: "Southern Hotel of our island",
    img: "https://do6raq9h04ex.cloudfront.net/sites/2/2021/03/146439688_1075312069646476_6626974179216859201_o.jpg",
  },
];

export default placeList;
